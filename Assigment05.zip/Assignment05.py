'''This project is like to the last one, but this time The ToDo file will contain two columns of data (Task, Priority) which you store in a Python dictionary. Each Dictionary will represent one row of data and these rows of data are added to a Python List to create a table of data.
1.	Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
3.	After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
6.	Save the data from the table into the Todo.txt file when the program exits.
Tip: I have provided a starting template to help you organize your code and help with some of the coding. You can use it or create your own file from scratch, but you have a lot of work to do in this module so, you may want to take advantage of the help.

'''
objFileName = "Todo.txt" # 1.Create a text file
strData = ""

lstTable = []

# # When the program starts, load each "row" of data
# Open and read the text file.
with open(objFileName, "r") as file:
    # #Add loop to read a single line of text from file.
    for line in file:
        # Separate to read each line
        # insert a new dictionary
        # in "ToDo.txt" into a python Dictionary.
        dicRow = {}
        items = line.strip().split(",")
        task = items[0]
        priority = items[1]
        dicRow["task"] = task
        dicRow["priority"] = priority
        # Add the each dictionary "row" to a python list "table"
        lstTable.append(dicRow)
        print(dicRow)

    print(lstTable)

# Step 2 - Display a menu of choices to the user
while True:
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        for row in lstTable:
            print(row)
        continue

    # Step 4 - Add a new item to the list/Table
    # Add code let users append new row of data.
    elif strChoice.strip() == '2':
        strTask = input("Enter a new task:")
        strPriority = input("Enter its priority:")
        dicNewRow = {"task": strTask.strip(), "priority": strPriority.strip().lower()}
        lstTable.append(dicNewRow)
        print(lstTable)
        continue
    # Step 5 - Remove a new item to the list/Table

    elif strChoice.strip() == '3':
        # input an item to remove
        strRemove = input("Enter the task you want to remove:")
        # Rerun the entire table list again but the removed item.
        newList = []
        for row in lstTable:
            if row["task"].strip().lower() != strRemove.strip().lower():
                newList.append(row)
        # Check if the input item exist in the table list.
        if len(lstTable) != len(newList):
            print(strRemove, "has been deleted")
            lstTable = newList
        else:
            print("The task does not exist.")

        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif strChoice.strip() == '4':
        with open(objFileName, "w") as file:
            for row in lstTable:
                file.write(str(row["task"]+","+row["priority"]+"\n"))
            print("Data has saved to file")

        continue
    elif strChoice.strip() == '5':
        break  # and Exit the program

