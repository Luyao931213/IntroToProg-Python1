#-------------------------------------------------#
# Title: Working with Todo list
# Dev:   Luyao Xu
# Date:  08/19/2018
# Desc: To Do List Functions
# ChangeLog:Luyao, 08/1902018,  Use function and Class to work with code
#-------------------------------------------------#

'''
1.	Make function for code that loads each row of data from txt file into dictionary and adds to a list
2.	Make function for code that displays contents of list
3.	Make function for code that allows user to add or remove tasks from the list
4.	Make function for code that saves data into txt file
5.	Make a class to hold the functions
'''

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Processing --#
# perform tasks
objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []

class todoFunction(object):
    ''' Create a class that contains options to edit list.'''
    #defin the method
    @staticmethod
    def readData(objFileName):
        """Read data from text file"""
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    @staticmethod
    def displayMenu():
        '''Display menu to users'''
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        return strChoice



    @staticmethod
    def showList():
        """Displays current list of tasks"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable

    @staticmethod
    def newList(strTask, strPriority, lstTable):
        """Adds new task to list"""
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
        #4a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable


    @staticmethod
    def removeData(strKeyToRemove, lstTable):
        """ Remove the task"""
        # 5a-Allow user to indicate which row to delete
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        # 5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return lstTable

    @staticmethod
    def saveData(objFileName):
        """Saves data to text file"""
        #5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #5b Ask if they want to save that data
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        return lstTable

# -- presentation (I/0) code --
# get user's input

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
todoFunction.readData(objFileName)
# Step 2
# Display a menu of choices to the user
while(True):

    strChoice = todoFunction.displayMenu()

    #adding a new line
    # Step 3
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        todoFunction.showList()
        continue
    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        todoFunction.newList(strTask, strPriority, lstTable)
        continue
    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        strKeyToRemove = input("Which TASK would you like removed? - ")
        todoFunction.removeData(strKeyToRemove, lstTable)
        continue
    # Step 6
    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        todoFunction.saveData(objFileName)
        continue
    # Step 7
    # Exit program
    elif (strChoice == '5'):
        break #and Exit the program


